﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TA_RSS_feed.Models
{
    public class RssFeed
    {
        public Rss Rss { get; set; }
    }
}
