
-- 01.c
-- Insert few records for testing
USE TransactSQL_HW_DB
GO

INSERT INTO Accounts(PersonId, Balance)
VALUES (1, 1000.0),
(2, 6636.5),
(3, 8227.53),
(4, 111282.234)
GO