
-- 01.b
-- Insert few records for testing
USE TransactSQL_HW_DB
GO

INSERT INTO Persons(FirstName, LastName, SSN)
VALUES ('Georgi', 'Georgiev', '123123123'),
('Petar', 'Petrov', '456456456'),
('Sasho', 'Alexandrov', '789789789'),
('Ivan', 'Ivanov', '555666777'),
('Kiril', 'Kirov', '111222333'),
('Maria', 'Petrova', '245223777')
GO