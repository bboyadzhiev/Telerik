USE TelerikAcademy
SELECT FirstName +'.' + LastName +'@telerik.com' as 'Full Email Addresses'
FROM Employees