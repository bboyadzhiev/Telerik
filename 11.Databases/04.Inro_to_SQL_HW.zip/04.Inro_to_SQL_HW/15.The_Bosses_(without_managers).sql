USE TelerikAcademy
SELECT * FROM Employees
WHERE ManagerID IS NULL