USE TelerikAcademy
SELECT Departments.Name FROM Departments
UNION
SELECT Towns.Name FROM Towns
