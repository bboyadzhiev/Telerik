USE TelerikAcademy
SELECT TOP 5 * FROM Employees
ORDER BY Salary DESC